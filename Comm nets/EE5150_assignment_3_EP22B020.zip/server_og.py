import socket
import threading
import time

buffer_size = 10
processing_rate = 10
weights = {5001: 1, 5002: 1, 5003: 1}

flow_VFT = {5001: 0, 5002: 0, 5003: 0}
curr_VFT = 0
active = 0
packet_queue = []
serv_count = [0, 0, 0]
start_time = time.time()

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(("", 4000))

def process_packets(buffer, rate):
    while True:
        #print("Hi")
        while len(buffer) > 0:
            dept_VFT, data, addr = buffer.pop(0)
            server_socket.sendto(data, addr)
            if addr[1] == 5001:
                serv_count[0] += 1
            elif addr[1] == 5002:
                serv_count[1] += 1
            elif addr[1] == 5003:
                serv_count[2] += 1

            flow_VFT[addr[1]] = dept_VFT
            time.sleep(1/rate)

processing_thread = threading.Thread(target=process_packets, args=(packet_queue, processing_rate), daemon=True)
processing_thread.start()
curr_time = time.time()

while True:
    try:
        data, addr = server_socket.recvfrom(1024)
        if addr[1] in weights.keys():
            arr_VFT = time.time()
            curr_VFT = max(flow_VFT[addr[1]], arr_VFT) + sum(weights.values())/(weights[addr[1]])   #for the packet
            if len(packet_queue) < buffer_size:
                packet_queue.append((curr_VFT,data,addr))
                packet_queue.sort()
            elif len(packet_queue) == buffer_size:
                # check if VFT is lower than the VFT of the last packet and pop as necessary
                if flow_VFT[addr[1]] < packet_queue[-1][0]:
                    packet_queue.append((curr_VFT,data,addr))
                    packet_queue.sort()
                    packet_queue.pop()

        if time.time()-curr_time>2:
            print(serv_count)
            print(flow_VFT[5001]-start_time, flow_VFT[5002]-start_time, flow_VFT[5003]-start_time)
            #print(sum(weights.values())/(processing_rate*weights[5001]), time.time()-start_time)
            print(len(packet_queue))
            '''for i in range(len(packet_queue)):
                if packet_queue[i][2][1] == 5001:
                    print('a', end = "")
                elif packet_queue[i][2][1] == 5002:
                    print('b', end = "")
                elif packet_queue[i][2][1] == 5003:
                    print('c', end = "")
                else:
                    print("gan only")
                    print(packet_queue[i])
            print()'''
            curr_time = time.time()
    except Exception as e:
        print(e)
        curr_time = time.time()
