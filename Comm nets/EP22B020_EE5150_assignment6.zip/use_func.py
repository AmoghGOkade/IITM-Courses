import random
import matplotlib.pyplot as plt

#most important parameters written here for ease of tweaking
nod_num = 10 # make 100 to obtain plots
l_len = 100
graph_counter = 0
figure, axis = plt.subplots(2, 2)
my_mark = 'x'

def simulate_exponential_backoff(n_nodes=10, L=5, simulation_time=10000):
    MAX_STAGE = 7
    nodes = []

    for _ in range(n_nodes):
        stage = 0
        backoff = random.randint(1, 2**(4 + stage))
        nodes.append({'stage': stage, 'counter': backoff, 'tx': 0, 'success': 0, 'collisions': 0})

    slot = 0
    tx_remaining = 0  # how many slots the current transmission still lasts
    total_collisions = 0
    total_successes = 0

    while slot < simulation_time:
        transmitting_nodes = []

        if tx_remaining > 0:
            tx_remaining -= 1
            slot += 1
            continue

        # Decrement backoff for all eligible nodes
        for node in nodes:
            if node['counter'] > 0:
                node['counter'] -= 1

        # Identify which nodes are transmitting now
        for idx, node in enumerate(nodes):
            if node['counter'] == 0:
                transmitting_nodes.append(idx)

        if len(transmitting_nodes) == 0:
            slot += 1
            continue

        # At least one node is transmitting
        for idx in transmitting_nodes:
            nodes[idx]['tx'] += 1

        if len(transmitting_nodes) == 1:
            # Success
            total_successes += 1
            nodes[transmitting_nodes[0]]['success'] += 1
            nodes[transmitting_nodes[0]]['stage'] = 0
            nodes[transmitting_nodes[0]]['counter'] = random.randint(1, 2**(4))
        else:
            # Collision
            total_collisions += 1
            for idx in transmitting_nodes:
                nodes[idx]['collisions'] += 1
                nodes[idx]['stage'] = min(nodes[idx]['stage'] + 1, MAX_STAGE)
                new_backoff = random.randint(1, 2**(4 + nodes[idx]['stage']))
                nodes[idx]['counter'] = new_backoff

        # Transmission takes L slots
        tx_remaining = L - 1
        slot += 1

    total_attempts = sum(node['tx'] for node in nodes)
    total_success = sum(node['success'] for node in nodes)
    total_collision = sum(node['collisions'] for node in nodes)

    throughput = total_success * L / simulation_time  # fraction of time slots used successfully

    return {    #total attempts = total_success + total_collision (both per node and overall)
        'total_attempts': total_attempts,
        'total_successes': total_success,
        'total_collisions': total_collision,
        'collision_rate': total_collision / total_attempts if total_attempts else 0,
        'success_rate': total_success / total_attempts if total_attempts else 0,
        'throughput': throughput,
        'per_node': [{'tx': n['tx'], 'success': n['success'], 'collisions': n['collisions']} for n in nodes]
    }

def make_plt(x, y, x_lab = "Blank", y_lab = "Blank", tit = "Blank", mark = 'o', col = "#1f77b4"):    #default from net
    plt.scatter(x,y, marker = mark, color = col)
    plt.plot(x,y, color = col)

    plt.title(tit, fontsize=18)
    plt.xlabel(x_lab, fontsize=15)
    plt.ylabel(y_lab,fontsize=15)

    plt.show()

def add_plt(x, y, x_lab = "Blank", y_lab = "Blank", tit = "Blank", mark = 'o', col = "#1f77b4"):    #default from net
    global graph_counter, axis
    graph_counter+=1

    if graph_counter == 1:
        (x_pos, y_pos) = (0,0)
    elif graph_counter == 2:
        (x_pos, y_pos) = (0,1)
    elif graph_counter == 3:
        (x_pos, y_pos) = (1,0)
    elif graph_counter == 4:
        (x_pos, y_pos) = (1,1)
        
    axis[x_pos, y_pos].scatter(x,y, marker = mark, color = col)
    axis[x_pos, y_pos].plot(x,y, color = col)

    axis[x_pos, y_pos].set_title(tit, fontsize=18)
    axis[x_pos, y_pos].set_xlabel(x_lab, fontsize=15)
    axis[x_pos, y_pos].set_ylabel(y_lab,fontsize=15)

n = []
tp_vs_n = []
cr_vs_n = []
for i in range(1, nod_num+1):
    d = simulate_exponential_backoff(i)
    #print(i, d, sep = ": ")
    n.append(i)
    tp_vs_n.append(d['throughput'])
    cr_vs_n.append(d['collision_rate'])

l = []
tp_vs_l = []
cr_vs_l = []
for i in range(1, l_len+1):
    d = simulate_exponential_backoff(L = i)
    l.append(i)
    tp_vs_l.append(d['throughput'])
    cr_vs_l.append(d['collision_rate'])

print("doing, wait")
add_plt(n, tp_vs_n, "number of nodes -->", "throughput (bits/slot) -->", "Plot of throughput vs number of nodes")
add_plt(n, cr_vs_n, "number of nodes -->", "collision rate -->", "Plot of collision rate vs number of nodes", my_mark)
add_plt(l, tp_vs_l, "transmission length -->", "throughput (bits/slot) -->", "Plot of throughput vs transmission length", col = "red")
add_plt(l, cr_vs_l, "transmission length -->", "collision rate -->", "Plot of collision rate vs transmission length", my_mark, col = "red")
#make_plt(n, tp_vs_n, "aaah -->", "gaaah -->", "heeheeheehaw")

plt.subplots_adjust(hspace=0.5, wspace=0.25)    #parameters to adjust the height and width spacing to prevent labels and titles from interfering with each other and/or the plots
plt.show()
