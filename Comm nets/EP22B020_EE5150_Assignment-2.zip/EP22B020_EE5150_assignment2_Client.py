import socket
import struct
import time

# server details
SERVER_IP = "127.0.0.1"
SERVER_PORT = 12345

TOTAL_PKTS = 10000

#is the time to wait if the last packet is dropped, so that we know to send an other batch of packets instead of waiting arbitrarily
timeout = 1 # initial value the timeout, which will later be adaptively calculated

proc_arr = []

first = False   #To stop exponential increase after the 1st packet loss and to reduce cwnd by 2 times for the 1st packet loss
flag = False    #flag to check whether the sequence has been broken due to duplicate ACKs or not (to receive and ignore unnecessary ACKs for the next batch of packets)
drop = False    #to check whether packet loss happens back to back, in which case the cwnd is reduced more drastically

clientSocket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
clientSocket.settimeout(timeout)

base = 0    #the counter for the number of successful packets (for which an ACK is received)
cwnd = 1
next_seq_num = 0 #the last packet of a batch that is sent

def send_packet_range(seq_range):
    for seq_no in seq_range:
        data = struct.pack('!I', seq_no)
        clientSocket.sendto(data, (SERVER_IP, SERVER_PORT))
    print(f"Sent packets: {seq_range[0]} to {seq_range[-1]}")

ini_time = time.time()  #initial time when start of transmission happens; used in throughput calculations
try:
    while next_seq_num < TOTAL_PKTS:
        print()
        print("cwnd: ",cwnd)
        
        next_seq_num = min(base+cwnd, TOTAL_PKTS)
        send_packet_range(range(base,next_seq_num))
        tout_ini = time.time()      # time at which a batch of pkts is sent

        try:    #used to catch time-outs
            oldbase = base      #variable used in calculating parameters needed for the adaptive timeout
            while base < next_seq_num:
                ack, addr = clientSocket.recvfrom(1024)
                ack_no = struct.unpack('!I', ack)[0]
                
                while flag == True and ack_no<base:    #receive (and ignore) all the duplicate ACKs sent after breaking due to detection of a duplicate ACK
                    ack, addr = clientSocket.recvfrom(1024)
                    ack_no = struct.unpack('!I', ack)[0]

                if ack_no == oldbase:   #time between the sending of packets and reception of the 1st ACK can be taken as the RTT of a single packet
                    rtt_pred = time.time() - tout_ini
                elif ack_no == oldbase + 1:     #the time between the 1st ACK and 2nd ACK is approximated to be the processing delay of the server
                    proc_delay = time.time() - rtt_pred - tout_ini
                
                if ack_no >= base:      #if a duplicate ACK is not received, it means that the ack_no and all packets before it are correct
                    base = ack_no + 1   #update the number of successful packets for a good ACK
                    flag = False    #flag to check whether the sequence has been broken due to duplicate ACKs or not (to receive and ignore unnecessary ACKs for the next batch of packets)
                    
                else:   #duplicate ACK
                    print("Old ACK ignored")
                    if first == False or drop == True:      #To stop exponential increase after the 1st packet loss and to reduce cwnd by 2 times for the 1st packet loss
                        first = True
                        cwnd = max(1, int(cwnd * 0.5))
                    else:       #to reduce cwnd by a lesser amount for rare packet losses
                        cwnd = max(1, int(cwnd * 0.8))      #0.8 was obtained by trial and error
                    flag = True
                    drop = True
                    break
                
            else:   #if the while loop exits without packet loss (all packets of a batch received successful ACKs)
                if first == False:      #initial exponential increase, which is a quick method to saturate to the buffer size, with the assumption that the 1st packet loss it due to buffer overflow
                    cwnd *= 2
                else:   #additive increase by 1 in all other cases
                    pass
                    cwnd += 1
                drop = False
                print(f"Received ACK: {ack_no}")

        except socket.timeout:      #no ACK was received even after the expected time. Indicates packet loss (of the last packet of the batch)
            print("Timeout, retransmitting...")
            if first == False or drop == True: # First timeout or continuous timeouts
                cwnd = max(1, int(cwnd * 0.5))
                first = True
            else:
                cwnd = max(1, int(cwnd * 0.8))
            drop = True

        finally:
            if cwnd > 2:
                timeout = (rtt_pred + proc_delay*cwnd)*1    #the time that we calculated was sufficient to wait for, such that no retransmission happens before the server has a chance to send back the ACK
                proc_arr.append(proc_delay)     #to keep track of the apparent/perceived processing delay of the server
                clientSocket.settimeout(timeout)    #updating the timeout mid program

                
except Exception as e:  #any exception other than timeouts
    print()
    print("xxxxxxxxxxxxxxxxx Error alert xxxxxxxxxxxxxxxxx")
    print(e)
    
finally:
    print()
    fin_time = time.time() - ini_time   #in seconds, so that the throughput is in packets per second
    print("Throughput = ",base/fin_time, "packets per second")    #throughput for how many ever packets have been sent successfully (and have received ACKs) till the client program is terminated, either due to an error or due to completion of all packets
    clientSocket.close()
    #print("Average proc del =", sum(proc_arr)/len(proc_arr))   #the average processing delay of the server perceived by the client, tracked to see whether the server's print statements would make a significant difference
